// Cerabond's Quick Strikes
// When a weapon or unarmed attack roll against a targeted token results in a hit or
// critical hit, automatically rolls damage and applies it to the target immediately.
// The rolling client handles damage to prevent duplicate rolls from multiple connected users.

const TAG = "Cerabond's Quick Strikes |";
const _SOCKET = "module.cerabonds-degrees-of-success";

// True while we are auto-rolling damage — used to gate the modifier dialog hook.
let _quickStrikeRollingDamage = false;

// The target token UUID for the damage roll currently in progress.
// Set before strike.damage/critical is called; cleared in the finally block.
let _pendingQuickStrikeTarget = null;

// ─── Dialog: suppress the DamageModifierDialog before it is ever painted ─────
// A MutationObserver callback fires as a microtask — after a DOM insertion but
// before the browser renders the next frame — so hiding the element here means
// it is never visible on screen.
let _dialogObserver = null;

function _startHidingDamageDialogs() {
    if (_dialogObserver) return;
    _dialogObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType !== 1) continue;
                if (node.classList.contains("damage-dialog") && node.classList.contains("roll-modifiers-dialog")) {
                    node.style.setProperty("display", "none", "important");
                }
            }
        }
    });
    _dialogObserver.observe(document.body, { childList: true });
}

function _stopHidingDamageDialogs() {
    _dialogObserver?.disconnect();
    _dialogObserver = null;
}

Hooks.on("renderDamageModifierDialog", (app) => {
    if (!_quickStrikeRollingDamage) return;
    console.log(TAG, "Auto-dismissing DamageModifierDialog");
    app.isRolled = true;
    app.close();
});

// ─── Tag: stamp the damage-roll chat message with our target UUID ─────────────
// For NPC attacks, PF2e may not populate context.target.token on the damage
// message even when we pass a target to strike.damage(). To work around this
// we stamp the message with our own flag before it reaches the database.
Hooks.on("preCreateChatMessage", (message, data, options, userId) => {
    if (!_quickStrikeRollingDamage || !_pendingQuickStrikeTarget) return;
    const pf2eContext = data.flags?.pf2e?.context;
    if (pf2eContext?.type !== "damage-roll") return;
    console.log(TAG, "Stamping damage-roll message → target:", _pendingQuickStrikeTarget);
    message.updateSource({ "flags.cerabonds.quickStrikes.targetUuid": _pendingQuickStrikeTarget });
});

// ─── Fix: resolve {actor}/{hpDamage} placeholders in damage-taken messages ────
// In Foundry v14, game.i18n.format() only substitutes when given a translation
// KEY — passing a pre-localized string (as PF2e master-branch applyDamage does)
// leaves the {actor} / {hpDamage} tokens as literals.  Intercept before the
// message is persisted and substitute them manually.
Hooks.on("preCreateChatMessage", (message, data) => {
    if (data.flags?.pf2e?.context?.type !== "damage-taken") return;
    if (!data.content?.includes("{actor}") && !data.content?.includes("{hpDamage}")) return;

    const scene = game.scenes.get(data.speaker?.scene ?? "");
    const speakerToken = scene?.tokens.get(data.speaker?.token ?? "");
    const actorName = (speakerToken?.name ?? data.speaker?.alias ?? "").replace(/[<>]/g, "");

    const updates = data.flags.pf2e.appliedDamage?.updates ?? [];
    const hpDamage = updates.reduce((sum, u) => sum + Math.abs(u?.value ?? 0), 0);

    message.updateSource({
        content: data.content
            .replace(/\{actor\}/g, actorName)
            .replace(/\{hpDamage\}/g, hpDamage),
    });
});

// ─── Socket: GM-side handler for delegated damage application ───────────────
// Players cannot modify tokens they don't own, so when permission is absent
// we emit a socket message and let the active GM apply the damage instead.
// This mirrors the save/elevate/restore pattern: we "note" the missing
// permission, "elevate" by delegating to the GM, and the GM's full access
// means nothing needs to be restored afterward.
Hooks.once("ready", () => {
    game.socket.on(_SOCKET, async (data) => {
        // Only the first active GM handles the request to avoid duplicate application.
        if (!game.user.isGM) return;
        if (game.users.activeGM?.id !== game.user.id) return;
        if (data.type !== "quickStrikeApplyDamage") return;

        const targetToken = await fromUuid(data.targetUuid);
        if (!targetToken) { console.warn(TAG, "[GM] Could not resolve target:", data.targetUuid); return; }
        const targetActor = targetToken.actor;
        if (!targetActor) { console.warn(TAG, "[GM] No actor on target:", data.targetUuid); return; }

        const message = game.messages.get(data.messageId);
        if (!message) { console.warn(TAG, "[GM] Message not found:", data.messageId); return; }
        const damageRoll = message.rolls[0];
        if (!damageRoll) { console.warn(TAG, "[GM] No damage roll in message:", data.messageId); return; }

        const pf2eContext = message.flags?.pf2e?.context;
        console.log(TAG, "[GM] Applying delegated damage → target:", data.targetUuid);
        try {
            await targetActor.applyDamage({
                damage: damageRoll,
                token: targetToken,
                rollOptions: new Set(pf2eContext?.options ?? []),
                outcome: pf2eContext?.outcome ?? null,
            });
            console.log(TAG, "[GM] Delegated damage applied successfully");
        } catch (err) {
            console.error(TAG, "[GM] Error applying delegated damage:", err);
        }
    });
});

// ─── Settings ─────────────────────────────────────────────────────────────────
Hooks.once("init", () => {
    game.settings.register("cerabonds-degrees-of-success", "quickStrikesEnabled", {
        name: "Quick Strikes: Auto-Roll Damage",
        hint: "Automatically roll and apply damage when your attack roll results in a hit or critical hit.",
        scope: "client",
        config: true,
        type: Boolean,
        default: false,
    });
});

// ─── Main hook ────────────────────────────────────────────────────────────────
Hooks.on("createChatMessage", async (message) => {
    // Only the rolling client acts to prevent duplicate actions across connected users.
    if (message.author?.id !== game.user.id) return;
    if (!game.settings.get("cerabonds-degrees-of-success", "quickStrikesEnabled")) return;

    const pf2eContext = message.flags?.pf2e?.context;

    // ── Damage-roll branch: apply damage if this message was stamped by us ──
    const targetUuid = message.flags?.cerabonds?.quickStrikes?.targetUuid;
    if (targetUuid && pf2eContext?.type === "damage-roll") {
        console.log(TAG, "Auto-applying damage → target:", targetUuid);

        const targetToken = await fromUuid(targetUuid);
        if (!targetToken) { console.warn(TAG, "Could not resolve target token:", targetUuid); return; }

        const targetActor = targetToken.actor;
        if (!targetActor) { console.warn(TAG, "Target token has no actor:", targetUuid); return; }

        const damageRoll = message.rolls[0];
        if (!damageRoll) { console.warn(TAG, "No damage roll in message"); return; }

        // GMs apply damage directly. Players always delegate via socket because
        // canUserModify() returns true client-side for some ActorDelta tokens but
        // the server still rejects the write — so we cannot rely on it as a gate.
        if (game.user.isGM) {
            try {
                // ActorPF2e.applyDamage() accepts an already-evaluated DamageRoll,
                // applies IWR (immunities/resistances/weaknesses), and updates HP.
                // It does NOT re-calculate or show any new dialog.
                await targetActor.applyDamage({
                    damage: damageRoll,
                    token: targetToken,
                    rollOptions: new Set(pf2eContext.options ?? []),
                    outcome: pf2eContext.outcome ?? null,
                });
                console.log(TAG, "Damage applied successfully");
            } catch (err) {
                console.error(TAG, "Error applying damage:", err);
            }
        } else {
            console.log(TAG, "Non-GM player — delegating damage application to GM via socket");
            game.socket.emit(_SOCKET, {
                type: "quickStrikeApplyDamage",
                targetUuid,
                messageId: message.id,
            });
        }

        // Close any DamageModifierDialog that is still open after the roll.
        // One may linger if the dialog opened after our renderDamageModifierDialog
        // hook already fired (e.g. a second async render pass).
        for (const app of Object.values(ui.windows)) {
            if (app.constructor?.name === "DamageModifierDialog") {
                console.log(TAG, "Closing lingering DamageModifierDialog");
                app.isRolled = true;
                app.close();
            }
        }
        _stopHidingDamageDialogs();

        return;
    }

    // ── Attack-roll branch: detect hit/crit, then roll damage ──
    if (!pf2eContext) return;
    if (!message.isRoll) return;
    if (pf2eContext.type !== "attack-roll" || pf2eContext.action !== "strike") return;

    // degreeOfSuccess: 2 = hit, 3 = critical hit
    const degreeOfSuccess = message.rolls[0]?.options?.degreeOfSuccess;
    if (degreeOfSuccess !== 2 && degreeOfSuccess !== 3) return;

    const actorUuid = pf2eContext.origin?.actor;
    if (!actorUuid) return;
    const actor = await fromUuid(actorUuid);
    if (!actor) { console.warn(TAG, "Could not resolve actor:", actorUuid); return; }

    // Item ID is the first segment of the identifier ("itemId.slug.melee|ranged")
    const itemId = pf2eContext.identifier?.split(".")[0];
    if (!itemId) return;

    const strikes = actor.system.actions;
    if (!Array.isArray(strikes) || strikes.length === 0) { console.warn(TAG, "No actions on actor"); return; }

    const strike = strikes.find(s => s.item?.id === itemId);
    if (!strike) { console.warn(TAG, `No strike for item "${itemId}" on "${actor.name}"`); return; }

    const targetTokenUuid = pf2eContext.target?.token;
    let targetTokenDoc = null;
    if (targetTokenUuid) targetTokenDoc = await fromUuid(targetTokenUuid);

    const outcomeLabel = degreeOfSuccess === 3 ? "critical hit" : "hit";
    console.log(TAG,
        `${actor.name} scored a ${outcomeLabel} with "${strike.item?.name}"` +
        (targetTokenDoc ? ` against ${targetTokenDoc.name}` : "") +
        " — rolling and applying damage automatically."
    );

    _quickStrikeRollingDamage = true;
    _pendingQuickStrikeTarget = targetTokenUuid ?? null;
    // Start intercepting any DamageModifierDialog before it can be painted.
    // Must be started here (not at the top of the hook) so it doesn't leak
    // and permanently suppress dialogs on non-qualifying messages.
    _startHidingDamageDialogs();
    try {
        if (degreeOfSuccess === 3) {
            await strike.critical({ target: targetTokenDoc, skipDialog: true });
        } else {
            await strike.damage({ target: targetTokenDoc, skipDialog: true });
        }
    } catch (err) {
        console.error(TAG, "Error during automatic damage roll:", err);
    } finally {
        _quickStrikeRollingDamage = false;
        _pendingQuickStrikeTarget = null;
        _stopHidingDamageDialogs();
    }
});
